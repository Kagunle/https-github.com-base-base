//! A task for finalizing an L2 block.

use std::{sync::Arc, time::Instant};

use async_trait::async_trait;
use base_common_genesis::RollupConfig;
use base_protocol::L2BlockInfo;
use derive_more::Constructor;

use crate::{
    EngineClient, EngineState, EngineTaskExt, FinalizeTaskError, Metrics, SynchronizeTask,
    state::EngineSyncStateUpdate,
};

/// The [`FinalizeTask`] fetches the [`L2BlockInfo`] at `block_number`, updates the [`EngineState`],
/// and dispatches a forkchoice update to finalize the block.
#[derive(Debug, Clone, Constructor)]
pub struct FinalizeTask<EngineClient_: EngineClient> {
    /// The engine client.
    pub client: Arc<EngineClient_>,
    /// The rollup config.
    pub cfg: Arc<RollupConfig>,
    /// The number of the L2 block to finalize.
    pub block_number: u64,
}

#[async_trait]
impl<EngineClient_: EngineClient> EngineTaskExt for FinalizeTask<EngineClient_> {
    type Output = ();

    type Error = FinalizeTaskError;

    async fn execute(&self, state: &mut EngineState) -> Result<(), FinalizeTaskError> {
        // Monotonicity guard: BinaryHeap does not define ordering between same-variant tasks,
        // so a stale FinalizeTask with a lower block number may be popped after a higher one
        // has already been executed. Skip it to prevent finalized_head from regressing.
        let finalized_head = state.sync_state.finalized_head().block_info.number;
        if self.block_number < finalized_head {
            debug!(
                target: "engine",
                block_number = self.block_number,
                finalized_head,
                "skipping stale finalize task"
            );
            return Ok(());
        }

        // Sanity check that the block that is being finalized is at least safe.
        if state.sync_state.safe_head().block_info.number < self.block_number {
            return Err(FinalizeTaskError::BlockNotSafe);
        }

        let block_fetch_start = Instant::now();
        let block = self
            .client
            .get_l2_block(self.block_number.into())
            .full()
            .await
            .map_err(FinalizeTaskError::TransportError)?
            .ok_or(FinalizeTaskError::BlockNotFound(self.block_number))?
            .into_consensus();
        let block_info = L2BlockInfo::from_block_and_genesis(
            &block.map_transactions(|tx| tx.inner.inner.into_inner()),
            &self.client.cfg().genesis,
        )
        .map_err(FinalizeTaskError::FromBlock)?;
        let block_fetch_duration = block_fetch_start.elapsed();

        // Dispatch a forkchoice update.
        let fcu_start = Instant::now();
        SynchronizeTask::new(
            Arc::clone(&self.client),
            Arc::clone(&self.cfg),
            EngineSyncStateUpdate { finalized_head: Some(block_info), ..Default::default() },
        )
        .execute(state)
        .await?;
        let fcu_duration = fcu_start.elapsed();
        let total_duration = block_fetch_start.elapsed();
        Metrics::engine_finalize_duration_seconds().record(total_duration.as_secs_f64());

        info!(
            target: "engine",
            hash = %block_info.block_info.hash,
            number = block_info.block_info.number,
            ?block_fetch_duration,
            ?fcu_duration,
            "Updated finalized head"
        );

        Ok(())
    }
}
