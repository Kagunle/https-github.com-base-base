//! Tests for `ConsolidateTask::execute`

use std::sync::Arc;

use alloy_consensus::transaction::Recovered;
use alloy_eips::{BlockNumberOrTag, Encodable2718};
use alloy_primitives::{Address, FixedBytes, b256};
use alloy_rpc_types_engine::{ForkchoiceUpdated, PayloadId, PayloadStatus, PayloadStatusEnum};
use alloy_rpc_types_eth::{Block as RpcBlock, BlockTransactions};
use base_common_consensus::{BaseTxEnvelope, TxDeposit};
use base_common_genesis::RollupConfig;
use base_common_rpc_types::Transaction as BaseTransaction;
use base_protocol::L1BlockInfoBedrock;

use crate::{
    AttributesMatch, AttributesMismatch, ConsolidateTask, EngineTaskExt,
    task_queue::tasks::consolidate::task::ConsolidateInput,
    test_utils::{TestAttributesBuilder, TestEngineStateBuilder, test_engine_client_builder},
};

fn l1_info_deposit_tx() -> BaseTxEnvelope {
    BaseTxEnvelope::from(TxDeposit {
        input: L1BlockInfoBedrock::default().encode_calldata(),
        ..Default::default()
    })
}

fn rpc_transaction(tx: BaseTxEnvelope, block_number: u64) -> BaseTransaction {
    BaseTransaction {
        inner: alloy_rpc_types_eth::Transaction {
            inner: Recovered::new_unchecked(tx, Address::ZERO),
            block_hash: None,
            block_number: Some(block_number),
            effective_gas_price: Some(0),
            transaction_index: Some(0),
        },
        deposit_nonce: None,
        deposit_receipt_version: None,
    }
}

/// Verifies that consolidation does NOT fatally error when safe head is behind
/// the unsafe head and the derived attributes don't match the existing block.
///
/// Previously, `SealTask` compared `state.sync_state.unsafe_head()` (the chain
/// tip, e.g. block 76) against `attributes.parent` (the safe head, e.g. block 34)
/// and returned `UnsafeHeadChangedSinceBuild` with Critical severity, crashing the
/// engine.  Op-node has no such check — the `BuildTask` already FCU'd the EL to the
/// correct parent, so the comparison is invalid.
///
/// After the fix the reconcile path proceeds to `seal_and_canonicalize_block`
/// directly, matching the reference node's behaviour.
///
/// This test FAILS on unfixed main and PASSES after the fix lands.
#[tokio::test]
async fn consolidate_does_not_crash_when_safe_behind_unsafe_and_attributes_mismatch() {
    let safe_head = crate::test_utils::test_block_info(34);
    let unsafe_head = crate::test_utils::test_block_info(76);

    // Attributes produced by derivation: parent = safe_head (block 34) → block 35.
    let attributes =
        TestAttributesBuilder::new().with_parent(safe_head).with_timestamp(2000).build();

    // Engine state: safe at 34, unsafe at 76.
    let mut state = TestEngineStateBuilder::new()
        .with_unsafe_head(unsafe_head)
        .with_safe_head(safe_head)
        .with_finalized_head(safe_head)
        .build();

    // Build a block at height 35 that does NOT match the attributes.
    // The key mismatch: parent_hash differs from attributes.parent.block_info.hash.
    // This makes `is_consistent_with_block` return false → triggers reconcile path.
    let mut mismatched_block = RpcBlock::<BaseTransaction>::default();
    mismatched_block.header.inner.number = 35;
    mismatched_block.header.inner.timestamp = 2000;
    mismatched_block.header.inner.parent_hash =
        b256!("deadbeefdeadbeefdeadbeefdeadbeefdeadbeefdeadbeefdeadbeefdeadbeef");

    // Mock client: return the mismatched block at number 35, and a Valid FCU
    // with a payload_id (needed by BuildTask inside the reconcile path).
    let valid_fcu = ForkchoiceUpdated {
        payload_status: PayloadStatus {
            status: PayloadStatusEnum::Valid,
            latest_valid_hash: Some(FixedBytes([2u8; 32])),
        },
        payload_id: Some(PayloadId::new([1u8; 8])),
    };
    let client = Arc::new(
        test_engine_client_builder()
            .with_l2_block_by_label(BlockNumberOrTag::Number(35), mismatched_block)
            .with_fork_choice_updated_v2_response(valid_fcu.clone())
            .with_fork_choice_updated_v3_response(valid_fcu)
            .build(),
    );

    let task = ConsolidateTask::new(
        client,
        Arc::new(RollupConfig::default()),
        ConsolidateInput::from(attributes),
    );

    // Execute — previously this returned Critical UnsafeHeadChangedSinceBuild.
    // Now it proceeds to seal_and_canonicalize_block (which will fail for other
    // reasons in a mock environment, but crucially NOT with the stale-unsafe-head
    // check that caused the crash loop).
    let result = task.execute(&mut state).await;

    // The task may still error (e.g. GetPayload fails in the mock) but it must
    // NOT be the stale-unsafe-head error that caused the crash loop.
    // The Display string for SealTaskError::UnsafeHeadChangedSinceBuild is
    // "Unsafe head changed between build and seal".
    if let Err(ref err) = result {
        let err_msg = format!("{err}");
        assert!(
            !err_msg.contains("Unsafe head changed between build and seal"),
            "must not fail with UnsafeHeadChangedSinceBuild: {err}"
        );
    }
}

#[tokio::test]
async fn consolidate_rejects_attribute_transaction_with_trailing_bytes() {
    let safe_head = crate::test_utils::test_block_info(0);
    let tx = l1_info_deposit_tx();
    let mut attr_tx = Vec::new();
    tx.encode_2718(&mut attr_tx);
    attr_tx.extend_from_slice(b"trailing bytes");

    let attributes = TestAttributesBuilder::new()
        .with_parent(safe_head)
        .with_transactions(vec![attr_tx.into()])
        .build();
    let block_number = attributes.block_number();

    let mut unsafe_block = RpcBlock::<BaseTransaction>::default();
    unsafe_block.header.inner.number = block_number;
    unsafe_block.header.inner.parent_hash = safe_head.block_info.hash;
    unsafe_block.header.inner.timestamp = attributes.attributes().payload_attributes.timestamp;
    unsafe_block.header.inner.mix_hash = attributes.attributes().payload_attributes.prev_randao;
    unsafe_block.header.inner.gas_limit = attributes.attributes().gas_limit.unwrap_or_default();
    unsafe_block.header.inner.parent_beacon_block_root =
        attributes.attributes().payload_attributes.parent_beacon_block_root;
    unsafe_block.transactions = BlockTransactions::Full(vec![rpc_transaction(tx, block_number)]);

    let cfg = RollupConfig::default();
    assert_eq!(
        AttributesMatch::check(&cfg, &attributes, &unsafe_block),
        AttributesMismatch::MalformedAttributesTransaction.into()
    );

    let mut state = TestEngineStateBuilder::new()
        .with_safe_head(safe_head)
        .with_unsafe_head(crate::test_utils::test_block_info(block_number))
        .build();
    let original_safe_head = state.sync_state.safe_head();
    let original_local_safe_head = state.sync_state.local_safe_head();
    let client = Arc::new(
        test_engine_client_builder()
            .with_l2_block_by_label(BlockNumberOrTag::Number(block_number), unsafe_block)
            .build(),
    );
    let task = ConsolidateTask::new(client, Arc::new(cfg), ConsolidateInput::from(attributes));

    let result = task.execute(&mut state).await;

    assert!(result.is_err());
    assert_eq!(state.sync_state.safe_head(), original_safe_head);
    assert_eq!(state.sync_state.local_safe_head(), original_local_safe_head);
}
