//! Contains the [`PollingTraversal`] stage of the derivation pipeline.

use alloc::{boxed::Box, sync::Arc};

use alloy_consensus::Receipt;
use alloy_eips::BlockNumHash;
use alloy_primitives::Address;
use async_trait::async_trait;
use base_common_genesis::{RollupConfig, SystemConfig};
use base_protocol::BlockInfo;
use tracing::{info, warn};

use crate::{
    ChainProvider, L1RetrievalProvider, Metrics, OriginAdvancer, OriginProvider, PipelineError,
    PipelineResult, ResetError, StageReset,
};

/// The [`PollingTraversal`] stage of the derivation pipeline.
///
/// This stage sits at the bottom of the pipeline, holding a handle to the data source
/// (a [`ChainProvider`] implementation) and the current L1 [`BlockInfo`] in the pipeline,
/// which are used to traverse the L1 chain. When the [`PollingTraversal`] stage is advanced,
/// it fetches the next L1 [`BlockInfo`] from the data source and updates the [`SystemConfig`]
/// with the receipts from the block.
#[derive(Debug, Clone)]
pub struct PollingTraversal<Provider: ChainProvider> {
    /// The current block in the traversal stage.
    pub block: Option<BlockInfo>,
    /// The data source for the traversal stage.
    pub data_source: Provider,
    /// Signals whether or not the traversal stage is complete.
    pub done: bool,
    /// The system config.
    pub system_config: SystemConfig,
    /// A reference to the rollup config.
    pub rollup_config: Arc<RollupConfig>,
}

#[async_trait]
impl<F: ChainProvider + Send> L1RetrievalProvider for PollingTraversal<F> {
    fn batcher_addr(&self) -> Address {
        self.system_config.batcher_address
    }

    async fn next_l1_block(&mut self) -> PipelineResult<Option<BlockInfo>> {
        if !self.done {
            self.done = true;
            Ok(self.block)
        } else {
            Err(PipelineError::Eof.temp())
        }
    }
}

impl<F: ChainProvider> PollingTraversal<F> {
    /// Creates a new [`PollingTraversal`] instance.
    pub fn new(data_source: F, cfg: Arc<RollupConfig>) -> Self {
        Self {
            block: Some(BlockInfo::default()),
            data_source,
            done: false,
            system_config: SystemConfig::default(),
            rollup_config: cfg,
        }
    }

    /// Update the origin block in the traversal stage.
    fn update_origin(&mut self, block: BlockInfo) {
        self.done = false;
        self.block = Some(block);
        Metrics::pipeline_origin().set(block.number as f64);
    }

    /// Updates the system config with receipts, logging each applied update and any errors,
    /// and setting the appropriate metrics gauges.
    pub fn update_system_config_with_receipts(
        &mut self,
        receipts: &[Receipt],
        l1_system_config_address: Address,
        ecotone_active: bool,
        block_number: u64,
    ) {
        let (updates, errors) = self.system_config.update_with_receipts(
            receipts,
            l1_system_config_address,
            ecotone_active,
        );
        for kind in &updates {
            info!(target: "traversal", %kind, block_number, "Applied system config update");
        }
        if !updates.is_empty() {
            Metrics::pipeline_latest_sys_config_update().set(block_number as f64);
        }
        for err in &errors {
            warn!(target: "traversal", error = ?err, block_number, "Malformed system config update (skipped)");
            Metrics::pipeline_sys_config_update_error().set(block_number as f64);
        }
    }
}

#[async_trait]
impl<F: ChainProvider + Send> OriginAdvancer for PollingTraversal<F> {
    /// Advances the internal state of the [`PollingTraversal`] stage to the next L1 block.
    /// This function fetches the next L1 [`BlockInfo`] from the data source and updates the
    /// [`SystemConfig`] with the receipts from the block.
    async fn advance_origin(&mut self) -> PipelineResult<()> {
        let mut timer = base_metrics::timed!(Metrics::pipeline_origin_advance());

        // Pull the next block or return EOF.
        // PipelineError::EOF has special handling further up the pipeline.
        let block = match self.block {
            Some(block) => block,
            None => {
                warn!(target: "l1_traversal",  "Missing current block, can't advance origin with no reference.");
                return Err(PipelineError::Eof.temp());
            }
        };
        let next_l1_origin =
            self.data_source.block_info_by_number(block.number + 1).await.map_err(Into::into)?;

        // Check block hashes for reorgs.
        if block.hash != next_l1_origin.parent_hash {
            return Err(ResetError::ReorgDetected(block.hash, next_l1_origin.parent_hash).into());
        }

        // Fetch receipts for the next l1 block and update the system config.
        let receipts =
            self.data_source.receipts_by_hash(next_l1_origin.hash).await.map_err(Into::into)?;

        let l1_system_config_address = self.rollup_config.l1_system_config_address;
        let ecotone_active = self.rollup_config.is_ecotone_active(next_l1_origin.timestamp);
        self.update_system_config_with_receipts(
            &receipts,
            l1_system_config_address,
            ecotone_active,
            next_l1_origin.number,
        );

        let prev_block_holocene = self.rollup_config.is_holocene_active(block.timestamp);
        let next_block_holocene = self.rollup_config.is_holocene_active(next_l1_origin.timestamp);

        // Update the block origin regardless of if a holocene activation is required.
        self.update_origin(next_l1_origin);

        timer.stop();

        // If the prev block is not holocene, but the next is, we need to flag this
        // so the pipeline driver will reset the pipeline for holocene activation.
        if !prev_block_holocene && next_block_holocene {
            return Err(ResetError::HoloceneActivation.reset());
        }

        Ok(())
    }
}

impl<F: ChainProvider> OriginProvider for PollingTraversal<F> {
    fn origin(&self) -> Option<BlockInfo> {
        self.block
    }
}

#[async_trait]
impl<F: ChainProvider + Send> StageReset for PollingTraversal<F> {
    async fn reset(
        &mut self,
        l1_origin: BlockNumHash,
        system_config: SystemConfig,
    ) -> PipelineResult<()> {
        let block =
            self.data_source.block_info_by_number(l1_origin.number).await.map_err(Into::into)?;
        self.update_origin(block);
        self.system_config = system_config;
        Ok(())
    }

    async fn activate(&mut self) -> PipelineResult<()> {
        // Activation is a no-op for the traversal stage: the L1 origin and system config
        // are preserved as-is; only higher stages need to clear their buffers.
        Ok(())
    }

    async fn flush_channel(&mut self) -> PipelineResult<()> {
        Ok(())
    }
}

#[cfg(test)]
pub(super) mod tests {
    use alloc::vec;

    use alloy_eips::BlockNumHash;
    use alloy_primitives::{address, b256};

    use super::*;
    use crate::{errors::PipelineErrorKind, test_utils::TraversalTestHelper};

    #[test]
    fn test_l1_traversal_batcher_address() {
        let mut traversal = TraversalTestHelper::new_populated();
        traversal.system_config.batcher_address = TraversalTestHelper::L1_SYS_CONFIG_ADDR;
        assert_eq!(traversal.batcher_addr(), TraversalTestHelper::L1_SYS_CONFIG_ADDR);
    }

    #[tokio::test]
    async fn test_l1_traversal_flush_channel() {
        let blocks = vec![BlockInfo::default(), BlockInfo::default()];
        let receipts = TraversalTestHelper::new_receipts();
        let mut traversal = TraversalTestHelper::new_from_blocks(blocks, receipts);
        assert!(traversal.advance_origin().await.is_ok());
        traversal.done = true;
        assert!(traversal.flush_channel().await.is_ok());
        assert_eq!(traversal.origin(), Some(BlockInfo::default()));
        assert!(traversal.done);
    }

    #[tokio::test]
    async fn test_l1_traversal_activation_signal() {
        let blocks = vec![BlockInfo::default(), BlockInfo::default()];
        let receipts = TraversalTestHelper::new_receipts();
        let mut traversal = TraversalTestHelper::new_from_blocks(blocks, receipts);
        assert!(traversal.advance_origin().await.is_ok());
        let cfg = traversal.system_config;
        traversal.done = true;
        assert!(traversal.activate().await.is_ok());
        // activate() is a no-op — origin and done flag remain unchanged.
        assert_eq!(traversal.origin(), Some(BlockInfo::default()));
        assert_eq!(traversal.system_config, cfg);
        assert!(traversal.done);
    }

    #[tokio::test]
    async fn test_l1_traversal_reset_signal() {
        let blocks = vec![BlockInfo::default(), BlockInfo::default()];
        let receipts = TraversalTestHelper::new_receipts();
        let mut traversal = TraversalTestHelper::new_from_blocks(blocks, receipts);
        assert!(traversal.advance_origin().await.is_ok());
        let cfg = SystemConfig::default();
        traversal.done = true;
        assert!(traversal.reset(BlockNumHash::default(), cfg).await.is_ok());
        assert_eq!(traversal.origin(), Some(BlockInfo::default()));
        assert_eq!(traversal.system_config, cfg);
        assert!(!traversal.done);
    }

    #[tokio::test]
    async fn test_l1_traversal() {
        let blocks = vec![BlockInfo::default(), BlockInfo::default()];
        let receipts = TraversalTestHelper::new_receipts();
        let mut traversal = TraversalTestHelper::new_from_blocks(blocks, receipts);
        assert_eq!(traversal.next_l1_block().await.unwrap(), Some(BlockInfo::default()));
        assert_eq!(traversal.next_l1_block().await.unwrap_err(), PipelineError::Eof.temp());
        assert!(traversal.advance_origin().await.is_ok());
    }

    #[tokio::test]
    async fn test_l1_traversal_missing_receipts() {
        let blocks = vec![BlockInfo::default(), BlockInfo::default()];
        let mut traversal = TraversalTestHelper::new_from_blocks(blocks, vec![]);
        assert_eq!(traversal.next_l1_block().await.unwrap(), Some(BlockInfo::default()));
        assert_eq!(traversal.next_l1_block().await.unwrap_err(), PipelineError::Eof.temp());
        matches!(
            traversal.advance_origin().await.unwrap_err(),
            PipelineErrorKind::Temporary(PipelineError::Provider(_))
        );
    }

    #[tokio::test]
    async fn test_l1_traversal_reorgs() {
        let hash = b256!("3333333333333333333333333333333333333333333333333333333333333333");
        let block = BlockInfo { hash, ..BlockInfo::default() };
        let blocks = vec![block, block];
        let receipts = TraversalTestHelper::new_receipts();
        let mut traversal = TraversalTestHelper::new_from_blocks(blocks, receipts);
        assert!(traversal.advance_origin().await.is_ok());
        let err = traversal.advance_origin().await.unwrap_err();
        assert_eq!(err, ResetError::ReorgDetected(block.hash, block.parent_hash).into());
    }

    #[tokio::test]
    async fn test_l1_traversal_missing_blocks() {
        let mut traversal = TraversalTestHelper::new_from_blocks(vec![], vec![]);
        assert_eq!(traversal.next_l1_block().await.unwrap(), Some(BlockInfo::default()));
        assert_eq!(traversal.next_l1_block().await.unwrap_err(), PipelineError::Eof.temp());
        matches!(
            traversal.advance_origin().await.unwrap_err(),
            PipelineErrorKind::Temporary(PipelineError::Provider(_))
        );
    }

    #[tokio::test]
    async fn test_l1_traversal_system_config_update_fails() {
        let blocks = vec![BlockInfo::default(), BlockInfo::default()];
        let receipts = TraversalTestHelper::new_receipts();
        let mut traversal = TraversalTestHelper::new_from_blocks(blocks, receipts);
        assert!(traversal.advance_origin().await.is_ok());
        // System config update failure is non-fatal — pipeline continues.
        assert!(traversal.advance_origin().await.is_ok());
    }

    #[tokio::test]
    async fn test_l1_traversal_system_config_updated() {
        let blocks = vec![BlockInfo::default(), BlockInfo::default()];
        let receipts = TraversalTestHelper::new_receipts();
        let mut traversal = TraversalTestHelper::new_from_blocks(blocks, receipts);
        assert_eq!(traversal.next_l1_block().await.unwrap(), Some(BlockInfo::default()));
        assert_eq!(traversal.next_l1_block().await.unwrap_err(), PipelineError::Eof.temp());
        assert!(traversal.advance_origin().await.is_ok());
        let expected = address!("000000000000000000000000000000000000bEEF");
        assert_eq!(traversal.system_config.batcher_address, expected);
    }
}
