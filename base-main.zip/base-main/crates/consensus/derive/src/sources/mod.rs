//! The data source module.
//!
//! Data sources are data providers for the derivation pipeline.
//! They implement the [`DataAvailabilityProvider`] trait, providing a way
//! to iterate over data for a given (L2) [`BlockInfo`].
//!
//! [DataAvailabilityProvider]: crate::traits::DataAvailabilityProvider
//! [BlockInfo]: base_protocol::BlockInfo

mod blob_data;
pub use blob_data::{BLOB_ENCODING_ROUNDS, BLOB_ENCODING_VERSION, BLOB_MAX_DATA_SIZE, BlobData};

mod ethereum;
pub use ethereum::EthereumDataSource;

mod blobs;
pub use blobs::BlobSource;

mod calldata;
pub use calldata::CalldataSource;
