use core::time::Duration;
use std::{
    ops::{Div, Rem},
    sync::Arc,
    time::Instant,
};

use alloy_consensus::{
    BlockBody, EMPTY_OMMER_ROOT_HASH, Header, Transaction, TxReceipt, constants::EMPTY_WITHDRAWALS,
    proofs,
};
use alloy_eips::{Encodable2718, eip7685::EMPTY_REQUESTS_HASH, merge::BEACON_NONCE};
use alloy_evm::Database;
use alloy_primitives::{Address, B256, Bloom, U256, logs_bloom, map::foldhash::HashMap};
use base_access_lists::FlashblockAccessList;
use base_builder_publish::WebSocketPublisher;
use base_bundles::RejectedTransaction;
use base_common_chains::Upgrades;
use base_common_consensus::{BaseReceipt, BaseTransactionSigned};
use base_common_flashblocks::{
    ExecutionPayloadBaseV1, ExecutionPayloadFlashblockDeltaV1, FlashblocksPayloadV1,
};
use base_execution_consensus::{calculate_receipt_root_no_memo, isthmus};
use base_execution_evm::{BaseEvmConfig, BaseNextBlockEnvAttributes};
use base_execution_payload_builder::{BaseBuiltPayload, BasePayloadBuilderAttributes};
use either::Either;
use eyre::WrapErr as _;
use reth_basic_payload_builder::BuildOutcome;
use reth_evm::{ConfigureEvm, execute::BlockBuilder};
use reth_execution_types::ChangedAccount;
use reth_node_api::{Block, BuiltPayloadExecutedBlock, PayloadBuilderError};
use reth_payload_primitives::PayloadBuilderAttributes;
use reth_payload_util::BestPayloadTransactions;
use reth_primitives_traits::RecoveredBlock;
use reth_provider::{
    BlockExecutionOutput, BlockExecutionResult, HashedPostStateProvider, ProviderError,
    StateRootProvider, StorageRootProvider,
};
use reth_revm::{
    State, database::StateProviderDatabase, db::states::bundle_state::BundleRetention,
};
use reth_transaction_pool::TransactionPool;
use reth_trie::{HashedPostState, updates::TrieUpdates};
use revm::Database as _;
use serde::{Deserialize, Serialize};
use serde_with::skip_serializing_none;
use tokio::sync::mpsc;
use tokio_util::sync::CancellationToken;
use tracing::{debug, error, info, metadata::Level, span, warn};

use crate::{
    BuilderConfig, BuilderMetrics, ExecutionInfo, PayloadBuilder, ResourceLimits,
    flashblocks::{
        FlashblocksExtraCtx,
        best_txs::BestFlashblocksTxs,
        context::BasePayloadBuilderCtx,
        generator::{BlockCell, BuildArguments},
    },
    traits::{ClientBounds, PoolBounds},
};

type NextBestFlashblocksTxs<Pool> = BestFlashblocksTxs<
    <Pool as TransactionPool>::Transaction,
    Box<
        dyn reth_transaction_pool::BestTransactions<
                Item = Arc<
                    reth_transaction_pool::ValidPoolTransaction<
                        <Pool as TransactionPool>::Transaction,
                    >,
                >,
            >,
    >,
>;

/// Base payload builder
#[derive(Debug, Clone)]
pub(super) struct BasePayloadBuilder<Pool, Client> {
    /// The type responsible for creating the evm.
    pub evm_config: BaseEvmConfig,
    /// The transaction pool
    pub pool: Pool,
    /// Node client
    pub client: Client,
    /// Sender for sending built payloads to [`PayloadHandler`],
    /// which broadcasts outgoing payloads via p2p.
    pub payload_tx: mpsc::Sender<BaseBuiltPayload>,
    /// WebSocket publisher for broadcasting flashblocks
    /// to all connected subscribers.
    pub ws_pub: Arc<WebSocketPublisher>,
    /// System configuration for the builder
    pub config: BuilderConfig,
    /// Sender for forwarding per-block batches of rejected transactions to the audit-archiver.
    pub rejected_tx_sender: Option<mpsc::Sender<Vec<RejectedTransaction>>>,
}

impl<Pool, Client> BasePayloadBuilder<Pool, Client> {
    /// `BasePayloadBuilder` constructor.
    pub(super) const fn new(
        evm_config: BaseEvmConfig,
        pool: Pool,
        client: Client,
        config: BuilderConfig,
        payload_tx: mpsc::Sender<BaseBuiltPayload>,
        ws_pub: Arc<WebSocketPublisher>,
        rejected_tx_sender: Option<mpsc::Sender<Vec<RejectedTransaction>>>,
    ) -> Self {
        Self { evm_config, pool, client, payload_tx, ws_pub, config, rejected_tx_sender }
    }
}

impl<Pool, Client> reth_basic_payload_builder::PayloadBuilder for BasePayloadBuilder<Pool, Client>
where
    Pool: Clone + Send + Sync,
    Client: Clone + Send + Sync,
{
    type Attributes = BasePayloadBuilderAttributes<BaseTransactionSigned>;
    type BuiltPayload = BaseBuiltPayload;

    fn try_build(
        &self,
        _args: reth_basic_payload_builder::BuildArguments<Self::Attributes, Self::BuiltPayload>,
    ) -> Result<BuildOutcome<Self::BuiltPayload>, PayloadBuilderError> {
        Err(PayloadBuilderError::Other(Box::new(std::io::Error::other(
            "try_build is not supported in flashblocks context",
        ))))
    }

    fn build_empty_payload(
        &self,
        _config: reth_basic_payload_builder::PayloadConfig<
            Self::Attributes,
            reth_basic_payload_builder::HeaderForPayload<Self::BuiltPayload>,
        >,
    ) -> Result<Self::BuiltPayload, PayloadBuilderError> {
        Err(PayloadBuilderError::Other(Box::new(std::io::Error::other(
            "build_empty_payload is not supported in flashblocks context",
        ))))
    }
}

impl<Pool, Client> BasePayloadBuilder<Pool, Client>
where
    Pool: PoolBounds,
    Client: ClientBounds,
{
    fn get_base_payload_builder_ctx(
        &self,
        config: reth_basic_payload_builder::PayloadConfig<
            BasePayloadBuilderAttributes<base_common_consensus::BaseTxEnvelope>,
        >,
        cancel: CancellationToken,
        extra: FlashblocksExtraCtx,
    ) -> eyre::Result<BasePayloadBuilderCtx> {
        let chain_spec = self.client.chain_spec();
        let timestamp = config.attributes.timestamp();

        let extra_data = if chain_spec.is_jovian_active_at_timestamp(timestamp) {
            config
                .attributes
                .get_jovian_extra_data(chain_spec.base_fee_params_at_timestamp(timestamp))
                .wrap_err("failed to get jovian extra data for flashblocks payload builder")?
        } else if chain_spec.is_holocene_active_at_timestamp(timestamp) {
            config
                .attributes
                .get_holocene_extra_data(chain_spec.base_fee_params_at_timestamp(timestamp))
                .wrap_err("failed to get holocene extra data for flashblocks payload builder")?
        } else {
            Default::default()
        };

        let block_env_attributes = BaseNextBlockEnvAttributes {
            timestamp,
            suggested_fee_recipient: config.attributes.suggested_fee_recipient(),
            prev_randao: config.attributes.prev_randao(),
            gas_limit: config.attributes.gas_limit.unwrap_or(config.parent_header.gas_limit),
            parent_beacon_block_root: config.attributes.payload_attributes.parent_beacon_block_root,
            extra_data,
        };

        let evm_config = self.evm_config.clone();

        let evm_env = evm_config
            .next_evm_env(&config.parent_header, &block_env_attributes)
            .wrap_err("failed to create next evm env")?;

        Ok(BasePayloadBuilderCtx {
            evm_config,
            chain_spec,
            config,
            evm_env,
            block_env_attributes,
            cancel,
            extra,
            builder_config: self.config.clone(),
            rejected_tx_sender: self.rejected_tx_sender.clone(),
        })
    }

    /// Constructs a Base payload from the transactions sent via the
    /// Payload attributes by the sequencer. If the `no_tx_pool` argument is passed in
    /// the payload attributes, the transaction pool will be ignored and the only transactions
    /// included in the payload will be those sent through the attributes.
    ///
    /// Given build arguments including a Base client, transaction pool,
    /// and configuration, this function creates a transaction payload. Returns
    /// a result indicating success with the payload or an error in case of failure.
    async fn build_payload(
        &self,
        args: BuildArguments<BasePayloadBuilderAttributes<BaseTransactionSigned>, BaseBuiltPayload>,
        best_payload: BlockCell<BaseBuiltPayload>,
    ) -> Result<(), PayloadBuilderError> {
        let block_build_start_time = Instant::now();
        let BuildArguments {
            mut cached_reads,
            config,
            cancel: block_cancel,
            finalized_cell,
            publish_guard,
        } = args;

        // We log only every Nth block based on sampling ratio to reduce usage
        let span = if config.parent_header.number.is_multiple_of(self.config.sampling_ratio) {
            span!(Level::INFO, "build_payload")
        } else {
            tracing::Span::none()
        };
        let _entered = span.enter();
        span.record("payload_id", config.attributes.payload_attributes.id.to_string());

        let timestamp = config.attributes.timestamp();
        let mut ctx = self
            .get_base_payload_builder_ctx(
                config,
                block_cancel.clone(),
                FlashblocksExtraCtx {
                    target_flashblock_count: self.config.flashblocks_per_block(),
                    ..Default::default()
                },
            )
            .map_err(|e| PayloadBuilderError::Other(e.into()))?;

        let state_provider = self.client.state_by_block_hash(ctx.parent().hash())?;
        let db = StateProviderDatabase::new(state_provider);

        // 1. execute the pre steps and seal an early block with that
        let sequencer_tx_start_time = Instant::now();
        let mut state =
            State::builder().with_database(cached_reads.as_db_mut(db)).with_bundle_update().build();

        let mut info = execute_pre_steps(&mut state, &ctx)?;
        let sequencer_tx_time = sequencer_tx_start_time.elapsed();
        BuilderMetrics::sequencer_tx_duration().record(sequencer_tx_time);
        BuilderMetrics::sequencer_tx_gauge().set(sequencer_tx_time);

        // We adjust our flashblocks timings based on time_drift if dynamic adjustment enable
        let (flashblocks_per_block, first_flashblock_offset) =
            self.calculate_flashblocks(timestamp);

        let skip_flashblocks_building = ctx.attributes().no_tx_pool || flashblocks_per_block == 0;

        let (payload, fb_payload) = build_block(
            &mut state,
            &ctx,
            &mut info,
            skip_flashblocks_building, // need to calculate state root for CL sync or if not building flashblocks
        )?;

        self.payload_tx.send(payload.clone()).await.map_err(PayloadBuilderError::other)?;
        best_payload.set(payload.clone());

        info!(
            target: "payload_builder",
            message = "Fallback block built",
            payload_id = fb_payload.payload_id.to_string(),
        );

        // not emitting flashblock if no_tx_pool in FCU, it's just syncing
        //
        // Published at flashblock_index 0. Regular flashblocks start at
        // index 1, so a client resuming from (block_number, 0) will skip
        // this fallback via the strictly-greater-than comparison in
        // `RingBuffer::entries_after`, but still receive all subsequent
        // flashblocks for the same block.
        if !ctx.attributes().no_tx_pool {
            let flashblock_byte_size = self
                .ws_pub
                .publish(&fb_payload, ctx.block_number(), 0)
                .map_err(PayloadBuilderError::other)?;
            BuilderMetrics::flashblock_byte_size_histogram().record(flashblock_byte_size as f64);
            BuilderMetrics::first_flashblock_time_offset()
                .record(first_flashblock_offset.as_millis() as f64);
            BuilderMetrics::reduced_flashblocks_number()
                .record(self.config.flashblocks_per_block().saturating_sub(flashblocks_per_block)
                    as f64);
        } else {
            info!(
                target: "payload_builder",
                "No transaction pool, skipping transaction pool processing",
            );
            BuilderMetrics::payload_num_tx().record(info.executed_transactions.len() as f64);
            BuilderMetrics::payload_num_tx_gauge().set(info.executed_transactions.len() as f64);
        }

        // fcu just arrived late, not syncing
        if flashblocks_per_block == 0 && !ctx.attributes().no_tx_pool {
            error!(
                target: "payload_builder",
                message = "FCU arrived too late or system clock are unsynced, building 0 flashblocks",
                timestamp,
            );

            self.record_flashblocks_metrics(
                &ctx,
                &info,
                flashblocks_per_block,
                &span,
                "FCU arrived too late or system clock are unsynced, building 0 flashblocks",
            );
        }

        if skip_flashblocks_building {
            finalized_cell.set(payload);
            let total_block_building_time = block_build_start_time.elapsed();
            BuilderMetrics::total_block_built_duration().record(total_block_building_time);
            BuilderMetrics::total_block_built_gauge().set(total_block_building_time);

            return Ok(());
        }

        info!(
            target: "payload_builder",
            message = "Performed flashblocks timing derivation",
            flashblocks_per_block,
            first_flashblock_offset = first_flashblock_offset.as_millis(),
            flashblocks_interval = self.config.flashblocks_interval.as_millis(),
        );

        let gas_per_batch = ctx.block_gas_limit() / flashblocks_per_block;
        let da_per_batch = ctx
            .builder_config
            .da_config
            .max_da_block_size()
            .map(|da_limit| da_limit / flashblocks_per_block);
        let da_footprint_per_batch =
            info.da_footprint_scalar.map(|_| ctx.block_gas_limit() / flashblocks_per_block);
        let execution_time_per_batch_us = ctx.builder_config.flashblock_execution_time_budget_us;
        let state_root_gas_per_batch = ctx
            .builder_config
            .block_state_root_gas_limit
            .map(|limit| limit / flashblocks_per_block);

        let extra = FlashblocksExtraCtx {
            flashblock_index: 1,
            target_flashblock_count: flashblocks_per_block,
            target_gas_for_batch: gas_per_batch,
            target_da_for_batch: da_per_batch,
            target_da_footprint_for_batch: da_footprint_per_batch,
            target_execution_time_for_batch_us: execution_time_per_batch_us,
            target_state_root_gas_for_batch: state_root_gas_per_batch,
            gas_per_batch,
            da_per_batch,
            da_footprint_per_batch,
            execution_time_per_batch_us,
            state_root_gas_per_batch,
        };

        let mut fb_cancel = block_cancel.child_token();
        ctx = ctx.with_cancel(fb_cancel.clone()).with_extra_ctx(extra);

        // Create best_transaction iterator
        let mut best_txs = BestFlashblocksTxs::new(
            BestPayloadTransactions::new(
                self.pool.best_transactions_with_attributes(ctx.best_transaction_attributes()),
            ),
            self.config.rejection_cache.clone(),
        );
        let interval = self.config.flashblocks_interval;
        let (tx, mut rx) = mpsc::channel((self.config.flashblocks_per_block() + 1) as usize);

        tokio::spawn({
            let block_cancel = block_cancel.clone();

            async move {
                let mut timer = tokio::time::interval_at(
                    tokio::time::Instant::now()
                        .checked_add(first_flashblock_offset)
                        .expect("can add flashblock offset to current time"),
                    interval,
                );

                loop {
                    tokio::select! {
                        _ = timer.tick() => {
                            // cancel current payload building job
                            fb_cancel.cancel();
                            fb_cancel = block_cancel.child_token();
                            // this will tick at first_flashblock_offset,
                            // starting the second flashblock
                            if tx.send(fb_cancel.clone()).await.is_err() {
                                // receiver channel was dropped, return.
                                // this will only happen if the `build_payload` function returns,
                                // due to payload building error or the main cancellation token being
                                // cancelled.
                                return;
                            }
                        }
                        _ = block_cancel.cancelled() => {
                            return;
                        }
                    }
                }
            }
        });

        // Highest executed nonce per sender, updated incrementally per flashblock.
        let mut executed_sender_nonces: HashMap<Address, u64> = HashMap::default();

        // Process flashblocks in a blocking loop
        loop {
            let fb_span = if span.is_none() {
                tracing::Span::none()
            } else {
                span!(
                    parent: &span,
                    Level::INFO,
                    "build_flashblock",
                )
            };
            let _entered = fb_span.enter();

            if ctx.flashblock_index() > ctx.target_flashblock_count() {
                self.record_flashblocks_metrics(
                    &ctx,
                    &info,
                    flashblocks_per_block,
                    &span,
                    "Payload building complete, target flashblock count reached",
                );
                self.finalize_payload(&mut state, &ctx, &mut info, &finalized_cell)?;
                return Ok(());
            }

            // build first flashblock immediately
            let next_flashblocks_ctx = match self
                .build_next_flashblock(
                    &ctx,
                    &mut info,
                    &mut state,
                    &mut best_txs,
                    &block_cancel,
                    &best_payload,
                    &publish_guard,
                    &fb_span,
                    &mut executed_sender_nonces,
                )
                .await
            {
                Ok(Some(next_flashblocks_ctx)) => next_flashblocks_ctx,
                Ok(None) => {
                    self.record_flashblocks_metrics(
                        &ctx,
                        &info,
                        flashblocks_per_block,
                        &span,
                        "Payload building complete, job cancelled or target flashblock count reached",
                    );
                    self.finalize_payload(&mut state, &ctx, &mut info, &finalized_cell)?;
                    return Ok(());
                }
                Err(err) => {
                    error!(
                        target: "payload_builder",
                        "Failed to build flashblock {} for block number {}: {}",
                        ctx.flashblock_index(),
                        ctx.block_number(),
                        err
                    );
                    return Err(PayloadBuilderError::Other(err.into()));
                }
            };

            tokio::select! {
                Some(fb_cancel) = rx.recv() => {
                    ctx = ctx.with_cancel(fb_cancel).with_extra_ctx(next_flashblocks_ctx);
                },
                _ = block_cancel.cancelled() => {
                    self.record_flashblocks_metrics(
                        &ctx,
                        &info,
                        flashblocks_per_block,
                        &span,
                        "Payload building complete, channel closed or job cancelled",
                    );
                    self.finalize_payload(&mut state, &ctx, &mut info, &finalized_cell)?;
                    return Ok(());
                }
            }
        }
    }

    #[allow(clippy::too_many_arguments)]
    async fn build_next_flashblock<
        DB: Database<Error = ProviderError> + std::fmt::Debug + AsRef<P> + revm::Database,
        P: StateRootProvider + HashedPostStateProvider + StorageRootProvider,
    >(
        &self,
        ctx: &BasePayloadBuilderCtx,
        info: &mut ExecutionInfo,
        state: &mut State<DB>,
        best_txs: &mut NextBestFlashblocksTxs<Pool>,
        block_cancel: &CancellationToken,
        best_payload: &BlockCell<BaseBuiltPayload>,
        publish_guard: &parking_lot::Mutex<()>,
        span: &tracing::Span,
        executed_sender_nonces: &mut HashMap<Address, u64>,
    ) -> eyre::Result<Option<FlashblocksExtraCtx>> {
        let flashblock_index = ctx.flashblock_index();
        let target_gas_for_batch = ctx.extra.target_gas_for_batch;
        let mut target_da_for_batch = ctx.extra.target_da_for_batch;
        let mut target_da_footprint_for_batch = ctx.extra.target_da_footprint_for_batch;
        let mut target_state_root_gas_for_batch = ctx.extra.target_state_root_gas_for_batch;
        let flashblock_execution_time_limit_us = ctx.extra.execution_time_per_batch_us;

        info!(
            target: "payload_builder",
            block_number = ctx.block_number(),
            flashblock_index,
            target_gas = target_gas_for_batch,
            gas_used = info.cumulative_gas_used,
            target_da = target_da_for_batch,
            da_used = info.cumulative_da_bytes_used,
            block_gas_used = ctx.block_gas_limit(),
            target_da_footprint = target_da_footprint_for_batch,
            flashblock_execution_time_limit_us = ?flashblock_execution_time_limit_us,
            target_state_root_gas_for_batch = ?target_state_root_gas_for_batch,
            "Building flashblock",
        );
        let flashblock_build_start_time = Instant::now();

        info.reset_flashblock_execution_time();

        // Correct the pool's sender nonce tracking before reading the next iterator.
        // `prune_transactions` clears sender_info, causing nonce-continuation txs to
        // land in `queued` instead of `pending` since the block isn't sealed yet.
        if !executed_sender_nonces.is_empty() {
            let changed_accounts: Vec<ChangedAccount> = executed_sender_nonces
                .iter()
                .map(|(&address, &nonce)| {
                    // Fall back to zero balance on error — conservatively parks the tx until the next block resolves it.
                    let balance = match state.basic(address) {
                        Ok(Some(info)) => info.balance,
                        Ok(None) => U256::ZERO,
                        Err(e) => {
                            warn!(address = %address, error = %e, "failed to read sender balance from state, defaulting to zero");
                            U256::ZERO
                        }
                    };
                    ChangedAccount { address, nonce: nonce + 1, balance }
                })
                .collect();
            self.pool.update_accounts(changed_accounts);
        }

        let best_txs_start_time = Instant::now();
        best_txs.refresh_iterator(BestPayloadTransactions::new(
            self.pool.best_transactions_with_attributes(ctx.best_transaction_attributes()),
        ));
        let transaction_pool_fetch_time = best_txs_start_time.elapsed();
        BuilderMetrics::transaction_pool_fetch_duration().record(transaction_pool_fetch_time);
        BuilderMetrics::transaction_pool_fetch_gauge().set(transaction_pool_fetch_time);

        let tx_execution_start_time = Instant::now();
        let limits = ResourceLimits {
            block_gas_limit: target_gas_for_batch.min(ctx.block_gas_limit()),
            tx_data_limit: ctx.builder_config.da_config.max_da_tx_size(),
            block_data_limit: target_da_for_batch,
            da_footprint_gas_scalar: info.da_footprint_scalar,
            block_da_footprint_limit: target_da_footprint_for_batch,
            tx_execution_time_limit_us: ctx.builder_config.max_execution_time_per_tx_us,
            flashblock_execution_time_limit_us,
            block_state_root_gas_limit: target_state_root_gas_for_batch,
            block_uncompressed_size_limit: ctx.builder_config.max_uncompressed_block_size,
        };
        let diag = ctx
            .execute_best_transactions(info, state, best_txs, &limits)
            .wrap_err("failed to execute best transactions")?;

        // Evict permanently rejected transactions from the iterator and pool.
        // The rejection cache (inside best_txs) prevents re-entry on P2P re-gossip.
        if !diag.permanently_rejected_txs.is_empty() {
            let rejected_count = diag.permanently_rejected_txs.len();
            best_txs.mark_rejected(&diag.permanently_rejected_txs);
            self.config.metering_provider.remove(&diag.permanently_rejected_txs);
            self.pool.remove_transactions(diag.permanently_rejected_txs.clone());
            info!(
                target: "payload_builder",
                count = rejected_count,
                "evicted permanently rejected transactions from pool",
            );
        }

        // Extract last transactions
        let new_transactions = info.executed_transactions[info.extra.last_flashblock_index..]
            .iter()
            .map(|tx| tx.tx_hash())
            .collect::<Vec<_>>();
        best_txs.mark_committed(&new_transactions);
        self.config.metering_provider.remove(&new_transactions);
        self.pool.prune_transactions(new_transactions);

        // Track executed nonces incrementally for the next flashblock's update_accounts call.
        debug_assert_eq!(
            info.executed_transactions.len(),
            info.executed_senders.len(),
            "executed_transactions and executed_senders must be in lockstep"
        );
        for (tx, sender) in info.executed_transactions[info.extra.last_flashblock_index..]
            .iter()
            .zip(info.executed_senders[info.extra.last_flashblock_index..].iter())
        {
            executed_sender_nonces
                .entry(*sender)
                .and_modify(|n| *n = (*n).max(tx.nonce()))
                .or_insert_with(|| tx.nonce());
        }

        // We got block cancelled, we won't need anything from the block at this point
        // Caution: this assume that block cancel token only cancelled when new FCU is received
        if block_cancel.is_cancelled() {
            self.record_flashblocks_metrics(
                ctx,
                info,
                ctx.target_flashblock_count(),
                span,
                "Payload building complete, channel closed or job cancelled",
            );
            return Ok(None);
        }

        let payload_transaction_simulation_time = tx_execution_start_time.elapsed();
        BuilderMetrics::payload_transaction_simulation_duration()
            .record(payload_transaction_simulation_time);
        BuilderMetrics::payload_transaction_simulation_gauge()
            .set(payload_transaction_simulation_time);

        let total_block_built_duration = Instant::now();
        let build_result = build_block(state, ctx, info, ctx.attributes().no_tx_pool);
        let total_block_built_duration = total_block_built_duration.elapsed();
        BuilderMetrics::total_block_built_duration().record(total_block_built_duration);
        BuilderMetrics::total_block_built_gauge().set(total_block_built_duration);

        match build_result {
            Err(err) => {
                BuilderMetrics::invalid_built_blocks_count().increment(1);
                Err(err).wrap_err("failed to build payload")
            }
            Ok((new_payload, mut fb_payload)) => {
                fb_payload.index = flashblock_index;
                fb_payload.base = None;

                // Synchronized check + publish.
                // The publish_guard mutex ensures that if get_payload (resolve_kind) is called,
                // it will either:
                // 1. Cancel before we acquire the lock → we see cancelled and return early
                // 2. Wait for us to release the lock → we publish, then it cancels (correct behavior)
                let (cancelled, flashblock_byte_size) = {
                    let _guard = publish_guard.lock();
                    if block_cancel.is_cancelled() {
                        (true, 0)
                    } else {
                        let size = self
                            .ws_pub
                            .publish(&fb_payload, ctx.block_number(), flashblock_index)
                            .wrap_err("failed to publish flashblock via websocket")?;
                        (false, size)
                    }
                };

                if cancelled {
                    self.record_flashblocks_metrics(
                        ctx,
                        info,
                        ctx.target_flashblock_count(),
                        span,
                        "Payload building complete, channel closed or job cancelled",
                    );
                    return Ok(None);
                }

                // Send to handler and set best_payload outside mutex.
                self.payload_tx
                    .send(new_payload.clone())
                    .await
                    .wrap_err("failed to send built payload to handler")?;
                best_payload.set(new_payload);

                // Record flashblock build duration
                BuilderMetrics::flashblock_build_duration()
                    .record(flashblock_build_start_time.elapsed());
                BuilderMetrics::flashblock_byte_size_histogram()
                    .record(flashblock_byte_size as f64);
                BuilderMetrics::flashblock_num_tx_histogram()
                    .record(info.executed_transactions.len() as f64);

                // Update bundle_state for next iteration
                if let Some(da_limit) = ctx.extra.da_per_batch {
                    if let Some(da) = target_da_for_batch.as_mut() {
                        *da += da_limit;
                    } else {
                        error!(
                            "Builder end up in faulty invariant, if da_per_batch is set then total_da_per_batch must be set"
                        );
                    }
                }

                let target_gas_for_batch = ctx.extra.target_gas_for_batch + ctx.extra.gas_per_batch;

                if let (Some(footprint), Some(da_footprint_limit)) =
                    (target_da_footprint_for_batch.as_mut(), ctx.extra.da_footprint_per_batch)
                {
                    *footprint += da_footprint_limit;
                }

                if let (Some(time), Some(time_per_batch)) =
                    (target_state_root_gas_for_batch.as_mut(), ctx.extra.state_root_gas_per_batch)
                {
                    *time += time_per_batch;
                }

                let next_extra = ctx.extra.clone().next(
                    target_gas_for_batch,
                    target_da_for_batch,
                    target_da_footprint_for_batch,
                    ctx.extra.execution_time_per_batch_us,
                    target_state_root_gas_for_batch,
                );

                let gas_headroom_pct = if limits.block_gas_limit > 0 {
                    (limits.block_gas_limit.saturating_sub(info.cumulative_gas_used) as f64
                        / limits.block_gas_limit as f64
                        * 100.0) as u64
                } else {
                    0
                };
                BuilderMetrics::record_flashblock_diagnostics(
                    flashblock_index,
                    &diag,
                    info,
                    &limits,
                );
                info!(
                    target: "payload_builder",
                    message = "Flashblock built",
                    flashblock_index = flashblock_index,
                    selection_outcome = diag.selection_outcome().as_str(),
                    rejection_reasons = ?diag.rejection_reasons(),
                    txs_considered = diag.txs_considered,
                    txs_included = diag.txs_included,
                    txs_rejected = diag.txs_rejected_total(),
                    min_priority_fee_wei = diag.min_priority_fee.unwrap_or(0),
                    current_gas = info.cumulative_gas_used,
                    target_gas = limits.block_gas_limit,
                    gas_headroom_pct = gas_headroom_pct,
                    current_da = info.cumulative_da_bytes_used,
                    flashblock_exec_time_us = info.flashblock_execution_time_us,
                    exec_time_limit_us = ?limits.flashblock_execution_time_limit_us,
                    cumulative_state_root_gas = info.cumulative_state_root_gas,
                    state_root_gas_limit = ?limits.block_state_root_gas_limit,
                    target_flashblocks = ctx.target_flashblock_count(),
                );

                Ok(Some(next_extra))
            }
        }
    }

    /// Do some logging and metric recording when we stop build flashblocks
    fn record_flashblocks_metrics(
        &self,
        ctx: &BasePayloadBuilderCtx,
        info: &ExecutionInfo,
        flashblocks_per_block: u64,
        span: &tracing::Span,
        message: &str,
    ) {
        BuilderMetrics::block_built_success().increment(1);
        BuilderMetrics::flashblock_count().record(ctx.flashblock_index() as f64);
        BuilderMetrics::missing_flashblocks_count()
            .record(flashblocks_per_block.saturating_sub(ctx.flashblock_index()) as f64);
        BuilderMetrics::payload_num_tx().record(info.executed_transactions.len() as f64);
        BuilderMetrics::payload_num_tx_gauge().set(info.executed_transactions.len() as f64);

        // Record cumulative state root gas for the block
        if info.cumulative_state_root_gas > 0 {
            BuilderMetrics::block_state_root_gas().record(info.cumulative_state_root_gas as f64);
        }

        // Record cumulative uncompressed block size
        BuilderMetrics::block_uncompressed_size().record(info.cumulative_uncompressed_bytes as f64);

        debug!(
            target: "payload_builder",
            message = message,
            flashblocks_per_block = flashblocks_per_block,
            flashblock_index = ctx.flashblock_index(),
        );

        span.record("flashblock_count", ctx.flashblock_index());
    }

    /// Finalize the payload by computing the state root and setting the finalized cell.
    fn finalize_payload<DB, P>(
        &self,
        state: &mut State<DB>,
        ctx: &BasePayloadBuilderCtx,
        info: &mut ExecutionInfo,
        finalized_cell: &BlockCell<BaseBuiltPayload>,
    ) -> Result<(), PayloadBuilderError>
    where
        DB: Database<Error = ProviderError> + AsRef<P>,
        P: StateRootProvider + HashedPostStateProvider + StorageRootProvider,
    {
        let start_time = Instant::now();

        // Build the final block WITH state root computed
        let (final_payload, _) = build_block(state, ctx, info, true)?;

        ctx.flush_rejected_txs(info);

        let elapsed = start_time.elapsed();
        info!(
            target: "payload_builder",
            block_number = ctx.block_number(),
            block_hash = ?final_payload.block().hash(),
            elapsed_ms = elapsed.as_millis(),
            "Finalized payload with state root"
        );

        finalized_cell.set(final_payload);

        Ok(())
    }

    /// Calculate number of flashblocks, taking time drift into account.
    pub(super) fn calculate_flashblocks(&self, timestamp: u64) -> (u64, Duration) {
        // We use this system time to determine remaining time to build a block
        // Things to consider:
        // FCU(a) - FCU with attributes
        // FCU(a) could arrive with `block_time - fb_time < delay`. In this case we could only produce 1 flashblock
        // FCU(a) could arrive with `delay < fb_time` - in this case we will shrink first flashblock
        // FCU(a) could arrive with `fb_time < delay < block_time - fb_time` - in this case we will issue less flashblocks
        let target_time = std::time::SystemTime::UNIX_EPOCH + Duration::from_secs(timestamp)
            - self.config.flashblocks_leeway_time;
        let now = std::time::SystemTime::now();
        let Some(time_drift) =
            target_time.duration_since(now).ok().filter(|duration| duration.as_millis() > 0)
        else {
            // in this case, we have no time to produce any flashblocks
            return (0, Duration::ZERO);
        };

        BuilderMetrics::flashblocks_time_drift().record(
            self.config.block_time.as_millis().saturating_sub(time_drift.as_millis()) as f64,
        );
        debug!(
            target: "payload_builder",
            message = "Time drift for building round",
            ?target_time,
            time_drift = self.config.block_time.as_millis().saturating_sub(time_drift.as_millis()),
            ?timestamp
        );
        // This is extra check to ensure that we would account at least for block time in case we have any timer discrepancies.
        let time_drift = time_drift.min(self.config.block_time);
        let interval = self.config.flashblocks_interval.as_millis() as u64;
        let time_drift = time_drift.as_millis() as u64;
        let first_flashblock_offset = time_drift.rem(interval);
        if first_flashblock_offset == 0 {
            // We have perfect division, so we use interval as first fb offset
            (time_drift.div(interval), Duration::from_millis(interval))
        } else {
            // Non-perfect division, so we account for it.
            (time_drift.div(interval) + 1, Duration::from_millis(first_flashblock_offset))
        }
    }
}

#[async_trait::async_trait]
impl<Pool, Client> PayloadBuilder for BasePayloadBuilder<Pool, Client>
where
    Pool: PoolBounds,
    Client: ClientBounds,
{
    type Attributes = BasePayloadBuilderAttributes<BaseTransactionSigned>;
    type BuiltPayload = BaseBuiltPayload;

    async fn try_build(
        &self,
        args: BuildArguments<Self::Attributes, Self::BuiltPayload>,
        best_payload: BlockCell<Self::BuiltPayload>,
    ) -> Result<(), PayloadBuilderError> {
        self.build_payload(args, best_payload).await
    }
}

#[skip_serializing_none]
#[derive(Debug, Serialize, Deserialize)]
struct FlashblocksMetadata {
    /// Receipts for transactions in this flashblock (removed in Base 1.0)
    receipts: Option<HashMap<B256, BaseReceipt>>,
    /// Changed account balances (removed in Base 1.0)
    new_account_balances: Option<HashMap<Address, U256>>,
    /// The block number this flashblock belongs to
    block_number: u64,
    /// The flashblock access list
    access_list: Option<FlashblockAccessList>,
}

pub(crate) fn execute_pre_steps<DB>(
    state: &mut State<DB>,
    ctx: &BasePayloadBuilderCtx,
) -> Result<ExecutionInfo, PayloadBuilderError>
where
    DB: Database<Error = ProviderError> + std::fmt::Debug + revm::Database,
{
    // 1. apply pre-execution changes
    ctx.evm_config
        .builder_for_next_block(state, ctx.parent(), ctx.block_env_attributes.clone())
        .map_err(PayloadBuilderError::other)?
        .apply_pre_execution_changes()?;

    // 2. execute sequencer transactions
    let info = ctx.execute_sequencer_transactions(state)?;

    Ok(info)
}

pub(crate) fn build_block<DB, P>(
    state: &mut State<DB>,
    ctx: &BasePayloadBuilderCtx,
    info: &mut ExecutionInfo,
    calculate_state_root: bool,
) -> Result<(BaseBuiltPayload, FlashblocksPayloadV1), PayloadBuilderError>
where
    DB: Database<Error = ProviderError> + AsRef<P> + revm::Database,
    P: StateRootProvider + HashedPostStateProvider + StorageRootProvider,
{
    // We use it to preserve state, so we run merge_transitions on transition state at most once
    let untouched_transition_state = state.transition_state.clone();
    let state_merge_start_time = Instant::now();
    state.merge_transitions(BundleRetention::Reverts);
    let state_transition_merge_time = state_merge_start_time.elapsed();
    BuilderMetrics::state_transition_merge_duration().record(state_transition_merge_time);
    BuilderMetrics::state_transition_merge_gauge().set(state_transition_merge_time);

    let block_number = ctx.block_number();
    let expected = ctx.parent().number + 1;
    if block_number != expected {
        return Err(PayloadBuilderError::Other(
            eyre::eyre!(
                "build context block number mismatch: expected {}, got {}",
                expected,
                block_number
            )
            .into(),
        ));
    }

    let receipts_root = calculate_receipt_root_no_memo(
        &info.receipts,
        &ctx.chain_spec,
        ctx.attributes().timestamp(),
    );
    let logs_bloom: Bloom = logs_bloom(info.receipts.iter().flat_map(|r| r.logs()));

    // TODO: maybe recreate state with bundle in here
    // calculate the state root
    let state_root_start_time = Instant::now();
    let mut state_root = B256::ZERO;
    let mut trie_output = TrieUpdates::default();
    let mut hashed_state = HashedPostState::default();

    if calculate_state_root {
        let state_provider = state.database.as_ref();
        hashed_state = state_provider.hashed_post_state(&state.bundle_state);
        (state_root, trie_output) =
            state_provider.state_root_with_updates(hashed_state.clone()).inspect_err(|err| {
                warn!(target: "payload_builder",
                    parent_header=%ctx.parent().hash(),
                    %err,
                    "failed to calculate state root for payload"
                );
            })?;
        let state_root_calculation_time = state_root_start_time.elapsed();
        BuilderMetrics::state_root_calculation_duration().record(state_root_calculation_time);
        BuilderMetrics::state_root_calculation_gauge().set(state_root_calculation_time);
    }

    let mut requests_hash = None;
    let withdrawals_root =
        if ctx.chain_spec.is_isthmus_active_at_timestamp(ctx.attributes().timestamp()) {
            // always empty requests hash post isthmus
            requests_hash = Some(EMPTY_REQUESTS_HASH);

            // withdrawals root field in block header is used for storage root of L2 predeploy
            // `l2tol1-message-passer`
            Some(
                isthmus::withdrawals_root(&state.bundle_state, state.database.as_ref())
                    .map_err(PayloadBuilderError::other)?,
            )
        } else if ctx.chain_spec.is_canyon_active_at_timestamp(ctx.attributes().timestamp()) {
            Some(EMPTY_WITHDRAWALS)
        } else {
            None
        };

    // create the block header
    let transactions_root = proofs::calculate_transaction_root(&info.executed_transactions);

    let (excess_blob_gas, blob_gas_used) = ctx.blob_fields(info);
    let extra_data = ctx.extra_data()?;

    let header = Header {
        parent_hash: ctx.parent().hash(),
        ommers_hash: EMPTY_OMMER_ROOT_HASH,
        beneficiary: ctx.evm_env.block_env.beneficiary,
        state_root,
        transactions_root,
        receipts_root,
        withdrawals_root,
        logs_bloom,
        timestamp: ctx.attributes().payload_attributes.timestamp,
        mix_hash: ctx.attributes().payload_attributes.prev_randao,
        nonce: BEACON_NONCE.into(),
        base_fee_per_gas: Some(ctx.base_fee()),
        number: ctx.parent().number + 1,
        gas_limit: ctx.block_gas_limit(),
        difficulty: U256::ZERO,
        gas_used: info.cumulative_gas_used,
        extra_data,
        parent_beacon_block_root: ctx.attributes().payload_attributes.parent_beacon_block_root,
        blob_gas_used,
        excess_blob_gas,
        requests_hash,
    };

    // seal the block
    let block = alloy_consensus::Block::<BaseTransactionSigned>::new(
        header,
        BlockBody {
            transactions: info.executed_transactions.clone(),
            ommers: vec![],
            withdrawals: ctx.withdrawals().cloned(),
        },
    );

    let recovered_block =
        RecoveredBlock::new_unhashed(block.clone(), info.executed_senders.clone());

    // Read account balances BEFORE take_bundle() empties the bundle state.
    let new_account_balances = state
        .bundle_state
        .state
        .iter()
        .filter_map(|(address, account)| account.info.as_ref().map(|info| (*address, info.balance)))
        .collect::<HashMap<Address, U256>>();

    // create the executed block data
    let executed = BuiltPayloadExecutedBlock {
        recovered_block: Arc::new(recovered_block),
        execution_output: Arc::new(BlockExecutionOutput {
            result: BlockExecutionResult {
                receipts: info.receipts.clone(),
                requests: vec![].into(),
                gas_used: info.cumulative_gas_used,
                blob_gas_used: 0,
            },
            state: state.take_bundle(),
        }),
        hashed_state: Either::Left(Arc::new(hashed_state)),
        trie_updates: Either::Left(Arc::new(trie_output)),
    };
    debug!(target: "payload_builder", message = "Executed block created");

    let sealed_block = Arc::new(block.seal_slow());
    debug!(target: "payload_builder", ?sealed_block, "sealed built block");

    let block_hash = sealed_block.hash();

    // pick the new transactions from the info field and update the last flashblock index
    let new_transactions = info.executed_transactions[info.extra.last_flashblock_index..].to_vec();

    let new_transactions_encoded =
        new_transactions.clone().into_iter().map(|tx| tx.encoded_2718().into()).collect::<Vec<_>>();

    let min_tx_index = info.extra.last_flashblock_index as u64;
    let max_tx_index = min_tx_index + new_transactions_encoded.len() as u64;

    let new_receipts = info.receipts[info.extra.last_flashblock_index..].to_vec();
    info.extra.last_flashblock_index = info.executed_transactions.len();

    let receipts_with_hash = new_transactions
        .iter()
        .zip(new_receipts.iter())
        .map(|(tx, receipt)| (tx.tx_hash(), receipt.clone()))
        .collect::<HashMap<B256, BaseReceipt>>();

    // finalize and build the FAL
    let fal_builder = std::mem::take(&mut info.extra.access_list_builder);
    let _access_list = fal_builder.build(min_tx_index, max_tx_index);

    let metadata: FlashblocksMetadata =
        if ctx.chain_spec.is_azul_active_at_timestamp(ctx.attributes().timestamp()) {
            FlashblocksMetadata {
                block_number: ctx.parent().number + 1,
                access_list: None,
                receipts: None,
                new_account_balances: None,
            }
        } else {
            FlashblocksMetadata {
                block_number: ctx.parent().number + 1,
                access_list: None,
                new_account_balances: Some(new_account_balances),
                receipts: Some(receipts_with_hash),
            }
        };

    // Prepare the flashblocks message
    let fb_payload = FlashblocksPayloadV1 {
        payload_id: ctx.payload_id(),
        index: 0,
        base: Some(ExecutionPayloadBaseV1 {
            parent_beacon_block_root: ctx
                .attributes()
                .payload_attributes
                .parent_beacon_block_root
                .ok_or_else(|| {
                    PayloadBuilderError::Other(
                        eyre::eyre!("parent beacon block root not found").into(),
                    )
                })?,
            parent_hash: ctx.parent().hash(),
            fee_recipient: ctx.attributes().suggested_fee_recipient(),
            prev_randao: ctx.attributes().payload_attributes.prev_randao,
            block_number: ctx.parent().number + 1,
            gas_limit: ctx.block_gas_limit(),
            timestamp: ctx.attributes().payload_attributes.timestamp,
            extra_data: ctx.extra_data()?,
            base_fee_per_gas: ctx.base_fee().try_into().unwrap(),
        }),
        diff: ExecutionPayloadFlashblockDeltaV1 {
            state_root,
            receipts_root,
            logs_bloom,
            gas_used: info.cumulative_gas_used,
            block_hash,
            transactions: new_transactions_encoded,
            withdrawals: ctx.withdrawals().cloned().unwrap_or_default().to_vec(),
            withdrawals_root: withdrawals_root.unwrap_or_default(),
            blob_gas_used,
        },
        metadata: serde_json::to_value(&metadata).unwrap_or_default(),
    };

    // We clean bundle and place initial state transaction back
    state.take_bundle();
    state.transition_state = untouched_transition_state;

    Ok((
        BaseBuiltPayload::new(ctx.payload_id(), sealed_block, info.total_fees, Some(executed)),
        fb_payload,
    ))
}

#[cfg(test)]
mod tests {
    use std::sync::Arc;

    use alloy_consensus::{Header, Receipt};
    use alloy_primitives::{Address, B256, Log, U256, map::foldhash::HashMap};
    use base_common_consensus::BaseReceipt;
    use base_common_flashblocks::Metadata;
    use base_execution_chainspec::BaseChainSpec;
    use reth_chainspec::ChainSpec;
    use reth_primitives_traits::SealedHeader;
    use reth_provider::noop::NoopProvider;
    use reth_revm::{State, database::StateProviderDatabase};

    use super::{FlashblocksMetadata, build_block};
    use crate::{ExecutionInfo, flashblocks::context::BasePayloadBuilderCtx};

    /// Creates a minimal [`BaseChainSpec`] with all L1 hardforks through Cancun
    /// active at genesis but **no** inherited rollup hardforks (Bedrock, Canyon,
    /// Ecotone, Holocene, Isthmus, Jovian are all absent).
    ///
    /// This keeps `build_block` on the simplest code paths: no blob fields,
    /// default extra data, no withdrawals root calculation.
    fn minimal_chain_spec() -> Arc<BaseChainSpec> {
        let genesis: serde_json::Value = serde_json::json!({
            "config": { "chainId": 901 },
            "gasLimit": "0x1C9C380",
            "timestamp": "0x0"
        });
        let genesis = serde_json::from_value(genesis).expect("valid genesis");

        let inner =
            ChainSpec::builder().chain(901.into()).genesis(genesis).cancun_activated().build();

        Arc::new(BaseChainSpec { inner })
    }

    /// Builds a sealed genesis header consistent with [`minimal_chain_spec`].
    fn genesis_header() -> Arc<SealedHeader> {
        let header = Header { gas_limit: 30_000_000, timestamp: 0, ..Default::default() };
        Arc::new(SealedHeader::seal_slow(header))
    }

    /// Verify that [`build_block`] produces a valid empty block when called
    /// with no transactions and `calculate_state_root = false`.
    ///
    /// This exercises the full block-assembly path (receipts root, logs bloom,
    /// header construction, flashblocks payload) using only in-memory state —
    /// no node, no disk, no network.
    #[test]
    fn build_block_empty_no_state_root() {
        let chain_spec = minimal_chain_spec();
        let parent = genesis_header();
        let ctx = BasePayloadBuilderCtx::for_test(chain_spec, Arc::clone(&parent));

        let db = StateProviderDatabase::new(NoopProvider::default());
        let mut state = State::builder().with_database(db).with_bundle_update().build();
        let mut info = ExecutionInfo::default();

        let (payload, fb_payload) =
            build_block::<_, NoopProvider>(&mut state, &ctx, &mut info, false)
                .expect("build_block should succeed for an empty block");

        // Block number must be parent + 1.
        assert_eq!(payload.block().number, parent.number + 1, "block number should be parent + 1");

        // No transactions were executed, so gas used must be zero.
        assert_eq!(payload.block().gas_used, 0, "empty block should use zero gas");

        // The flashblocks payload must reference the same block.
        assert_eq!(fb_payload.diff.block_hash, payload.block().hash(), "hash mismatch");
    }

    /// Verify that [`build_block`] exercises the state root calculation path
    /// when `calculate_state_root = true`.
    ///
    /// With [`NoopProvider`], both `hashed_post_state` and
    /// `state_root_with_updates` return defaults, so the state root ends up
    /// as [`B256::ZERO`].  The important property under test is that the
    /// `calculate_state_root = true` branch runs without error and the
    /// resulting header carries the computed root.
    #[test]
    fn build_block_empty_with_state_root() {
        let chain_spec = minimal_chain_spec();
        let parent = genesis_header();
        let ctx = BasePayloadBuilderCtx::for_test(chain_spec, Arc::clone(&parent));

        let db = StateProviderDatabase::new(NoopProvider::default());
        let mut state = State::builder().with_database(db).with_bundle_update().build();
        let mut info = ExecutionInfo::default();

        let (payload, _fb_payload) =
            build_block::<_, NoopProvider>(&mut state, &ctx, &mut info, true)
                .expect("build_block with state root should succeed");

        // NoopProvider returns B256::default() for all state root queries,
        // which equals B256::ZERO.
        assert_eq!(
            payload.block().state_root,
            B256::ZERO,
            "NoopProvider should yield a zero state root"
        );

        assert_eq!(payload.block().number, parent.number + 1);
    }

    /// [`build_block`] must return an error when the EVM environment's block
    /// number does not match `parent.number + 1`.
    ///
    /// In production this would indicate a bug in context construction or a
    /// stale parent header.  The guard at the top of `build_block` exists to
    /// catch exactly this class of misconfiguration.
    #[test]
    fn build_block_rejects_block_number_mismatch() {
        let chain_spec = minimal_chain_spec();
        let parent = genesis_header();
        let mut ctx = BasePayloadBuilderCtx::for_test(chain_spec, Arc::clone(&parent));

        // Tamper with the EVM block number so it disagrees with parent + 1.
        // parent.number is 0, so the expected block number is 1.
        // Setting it to 99 should trigger the mismatch guard.
        ctx.evm_env.block_env.number = U256::from(99);

        let db = StateProviderDatabase::new(NoopProvider::default());
        let mut state = State::builder().with_database(db).with_bundle_update().build();
        let mut info = ExecutionInfo::default();

        let err = build_block::<_, NoopProvider>(&mut state, &ctx, &mut info, false)
            .expect_err("build_block should fail on block number mismatch");

        let msg = err.to_string();
        assert!(
            msg.contains("block number mismatch"),
            "error should mention block number mismatch, got: {msg}"
        );
    }

    /// [`build_block`] must return an error when the payload attributes lack
    /// a `parent_beacon_block_root`.
    ///
    /// The flashblocks payload construction unconditionally reads this field,
    /// so a `None` value is an unrecoverable configuration error that should
    /// surface clearly rather than panicking.
    #[test]
    fn build_block_rejects_missing_beacon_block_root() {
        let chain_spec = minimal_chain_spec();
        let parent = genesis_header();
        let mut ctx = BasePayloadBuilderCtx::for_test(chain_spec, Arc::clone(&parent));

        // Clear the parent beacon block root that for_test() sets.
        ctx.config.attributes.payload_attributes.parent_beacon_block_root = None;

        let db = StateProviderDatabase::new(NoopProvider::default());
        let mut state = State::builder().with_database(db).with_bundle_update().build();
        let mut info = ExecutionInfo::default();

        let err = build_block::<_, NoopProvider>(&mut state, &ctx, &mut info, false)
            .expect_err("build_block should fail without beacon block root");

        let msg = err.to_string();
        assert!(
            msg.contains("parent beacon block root not found"),
            "error should mention missing beacon block root, got: {msg}"
        );
    }

    /// Pin the JSON field names and structure of [`FlashblocksMetadata`].
    ///
    /// This struct is serialized into the `metadata` field of the flashblocks
    /// websocket payload. Changing field names, types, or serde attributes
    /// without updating downstream consumers is a breaking change.
    #[test]
    fn flashblocks_metadata_json_format_is_stable() {
        let tx_hash = B256::from([0xAA; 32]);
        let address = Address::from([0xBB; 20]);

        let receipt = BaseReceipt::Eip1559(Receipt {
            status: true.into(),
            cumulative_gas_used: 21_000,
            logs: Vec::<Log>::new(),
        });

        let mut receipts = HashMap::default();
        receipts.insert(tx_hash, receipt);

        let mut balances = HashMap::default();
        balances.insert(address, U256::from(1_000_000_000_000_000_000u128));

        let metadata = FlashblocksMetadata {
            receipts: Some(receipts),
            new_account_balances: Some(balances),
            block_number: 42,
            access_list: None,
        };

        let json = serde_json::to_value(&metadata).unwrap();
        let obj = json.as_object().unwrap();

        // Verify exact field set
        let mut keys: Vec<&String> = obj.keys().collect();
        keys.sort();
        assert_eq!(
            keys,
            vec!["block_number", "new_account_balances", "receipts"],
            "metadata field names changed"
        );

        // block_number is a plain integer, not hex-encoded
        assert_eq!(obj["block_number"], serde_json::json!(42));

        // receipts is a map keyed by tx hash
        let receipts_obj = obj["receipts"].as_object().unwrap();
        let tx_key = format!("{tx_hash:#x}");
        assert!(receipts_obj.contains_key(&tx_key), "receipt should be keyed by tx hash");

        // receipt has internally-tagged type field
        let receipt_json = &receipts_obj[&tx_key];
        assert_eq!(receipt_json["type"], "0x2", "EIP-1559 receipt type tag must be 0x2");

        // new_account_balances is a map keyed by address
        let balances_obj = obj["new_account_balances"].as_object().unwrap();
        let addr_key = format!("{address:#x}");
        assert!(balances_obj.contains_key(&addr_key), "balance should be keyed by address");
    }

    /// The client-side [`Metadata`] type must be able to deserialize from
    /// `FlashblocksMetadata` JSON, ignoring the extra fields.
    #[test]
    fn client_metadata_deserializes_from_builder_metadata() {
        let metadata = FlashblocksMetadata {
            receipts: Some(HashMap::default()),
            new_account_balances: Some(HashMap::default()),
            block_number: 99,
            access_list: None,
        };

        let json = serde_json::to_value(&metadata).unwrap();
        let client_metadata: Metadata =
            serde_json::from_value(json).expect("client Metadata must parse builder metadata");
        assert_eq!(client_metadata.block_number, 99);
    }

    /// The v0.4.1 metadata format (only `block_number`) must still deserialize
    /// into the client-side [`Metadata`] type.
    #[test]
    fn client_metadata_deserializes_from_v0_4_1_format() {
        let json = serde_json::json!({"block_number": 123});
        let metadata: Metadata = serde_json::from_value(json).expect("v0.4.1 metadata must parse");
        assert_eq!(metadata.block_number, 123);
    }
}
